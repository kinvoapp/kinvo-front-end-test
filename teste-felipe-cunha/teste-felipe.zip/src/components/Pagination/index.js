import React from 'react'

const Pagination = ({ itemsPerPage, totalItems, paginate }) => {
    const itemNumbers = [];

    for(let i = 1; i <= Math.ceil(totalItems / itemsPerPage); i++) {
        itemNumbers.push(i);
    }

    return (
        <nav>
            <ul className="pagination">
                {itemNumbers.map(number =>(
                    <li key={number} className='page-item'>
                        <a onClick={() => paginate(number)} href='#' className='page-link'>
                            {number}
                        </a>
                    </li>
                ))}
            </ul>
        </nav>
    )
}

export default Pagination
