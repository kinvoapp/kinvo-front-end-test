import styled from 'styled-components';

export const Container = styled.div`
  background: #fff;
  height: 88vh;
  width: 250px;
  min-width: 250px;
`;
